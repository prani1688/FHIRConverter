﻿extern alias R3;
using AutoMapper;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static R3::Hl7.Fhir.Model.MedicationStatement;
using R3Model = R3.Hl7.Fhir.Model;

namespace FHIR.HL7
{

    class Program
    {
        static void Main(string[] args)
        {
            // Initialize AutoMapper and configure it with the custom profile
            var config = new MapperConfiguration(cfg => cfg.AddProfile<R3ToR4MappingProfile>());
            var mapper = new Mapper(config);

            // Your JSON data in FHIR R3 format (example)
            string jsonR3Data = @"{
  ""resourceType"": ""MedicationStatement"",
  ""id"": ""example004"",
  ""text"": {
    ""status"": ""generated"",
    ""div"": ""<div xmlns=\""http://www.w3.org/1999/xhtml\""><p><b>Generated Narrative with Details</b></p><p><b>id</b>: example004</p><p><b>partOf</b>: <a>Observation/blood-pressure</a></p><p><b>status</b>: completed</p><p><b>medication</b>: Amoxicillin (product) <span>(Details : {SNOMED CT code '27658006' = 'p-Hydroxyampicillin', given as 'Amoxicillin (product)'})</span></p><p><b>effective</b>: 23/01/2014</p><p><b>dateAsserted</b>: 22/02/2015</p><p><b>informationSource</b>: <a>Donald Duck</a></p><p><b>subject</b>: <a>Donald Duck</a></p><p><b>taken</b>: y</p><p><b>reasonCode</b>: Otitis Media <span>(Details : {SNOMED CT code '65363002' = 'Otitis media', given as 'Otitis Media'})</span></p><p><b>note</b>: Patient indicates they miss the occasional dose</p><p><b>dosage</b>: </p></div>""
  },
  ""partOf"": [
    {
      ""reference"": ""Observation/blood-pressure""
    }
  ],
  ""status"": ""completed"",
  ""medicationCodeableConcept"": {
    ""coding"": [
      {
        ""system"": ""http://snomed.info/sct"",
        ""code"": ""27658006"",
        ""display"": ""Amoxicillin (product)""
      }
    ]
  },
  ""effectiveDateTime"": ""2014-01-23"",
  ""dateAsserted"": ""2015-02-22"",
  ""informationSource"": {
    ""reference"": ""Patient/pat1"",
    ""display"": ""Donald Duck""
  },
  ""subject"": {
    ""reference"": ""Patient/pat1"",
    ""display"": ""Donald Duck""
  },
 ""taken"": ""y"",
  ""reasonCode"": [
    {
      ""coding"": [
        {
          ""system"": ""http://snomed.info/sct"",
          ""code"": ""65363002"",
          ""display"": ""Otitis Media""
        }
      ]
    }
  ],
  ""note"": [
    {
      ""text"": ""Patient indicates they miss the occasional dose""
    }
  ],
  ""dosage"": [
    {
      ""text"": ""one capsule three times daily"",
      ""timing"": {
        ""repeat"": {
          ""frequency"": 3,
          ""period"": 1,
          ""periodUnit"": ""d""
        }
      },
      ""asNeededBoolean"": false,
      ""route"": {
        ""coding"": [
          {
            ""system"": ""http://snomed.info/sct"",
            ""code"": ""260548002"",
            ""display"": ""Oral""
          }
        ]
      },
      ""maxDosePerPeriod"": {
        ""numerator"": {
          ""value"": 3,
          ""unit"": ""capsules"",
          ""system"": ""http://snomed.info/sct"",
          ""code"": ""385055001""
        },
        ""denominator"": {
          ""value"": 1,
          ""system"": ""http://unitsofmeasure.org"",
          ""code"": ""d""
        }
      }
    }
  ]
}";
           
            var parser = new R3.Hl7.Fhir.Serialization.FhirJsonParser();

            var medicationStatement = parser.Parse<R3Model.MedicationStatement>(jsonR3Data);

            // Map the FHIR R3 object to FHIR R4
            
            var target = mapper.Map<MedicationStatement>(medicationStatement);

            // Serialize the FHIR R4 object to JSON (example)
            string jsonR4Data = JsonConvert.SerializeObject(target, Formatting.Indented);
            Console.WriteLine("FHIR R4 Data:");
            Console.WriteLine(jsonR4Data);

            // You can perform further processing or save the converted data as needed.
        }
    }




    //public R3Model.MedicationStatement ConvertToR3MedicationStatement()
    //{
    //    R3Model.MedicationStatement medicationStatement = new R3Model.MedicationStatement
    //    {
    //        Id = "example001",
    //        Status = MedicationStatement.MedicationStatementStatus.Active,
    //        Category = new CodeableConcept
    //        {
    //            Coding = new List<Coding>
    //            {
    //                new Coding
    //                {
    //                    System = "http://hl7.org/fhir/medication-statement-category",
    //                    Code = "inpatient",
    //                    Display = "Inpatient"
    //                }
    //            }
    //        },
    //        Medication = new ResourceReference
    //        {
    //            Reference = "#med0309"
    //        },
    //        Effective = new Period
    //        {
    //            Start = "2015-01-23"
    //        },
    //        DateAsserted = "2015-02-22",
    //        InformationSource = new ResourceReference
    //        {
    //            Reference = "Patient/pat1",
    //            Display = "Donald Duck"
    //        },
    //        Subject = new ResourceReference
    //        {
    //            Reference = "Patient/pat1",
    //            Display = "Donald Duck"
    //        },
    //        DerivedFrom = new List<ResourceReference>
    //        {
    //            new ResourceReference
    //            {
    //                Reference = "MedicationRequest/medrx002"
    //            }
    //        },
    //        Taken = MedicationStatement.MedicationStatementTaken.N,
    //        ReasonCode = new List<CodeableConcept>
    //        {
    //            new CodeableConcept
    //            {
    //                Coding = new List<Coding>
    //                {
    //                    new Coding
    //                    {
    //                        System = "http://snomed.info/sct",
    //                        Code = "32914008",
    //                        Display = "Restless Legs"
    //                    }
    //                }
    //            }
    //        },
    //        Note = new List<Annotation>
    //        {
    //            new Annotation
    //            {
    //                Text = "Patient indicates they miss the occasional dose"
    //            }
    //        },
    //        Dosage = new List<MedicationStatement.DosageComponent>
    //        {
    //            new MedicationStatement.DosageComponent
    //            {
    //                Sequence = 1,
    //                Text = "1-2 tablets once daily at bedtime as needed for restless legs",
    //                AdditionalInstruction = new List<CodeableConcept>
    //                {
    //                    new CodeableConcept
    //                    {
    //                        Text = "Taking at bedtime"
    //                    }
    //                },
    //                Timing = new Timing
    //                {
    //                    Repeat = new Timing.TimingRepeatComponent
    //                    {
    //                        Frequency = 1,
    //                        Period = 1,
    //                        PeriodUnit = "d"
    //                    }
    //                },
    //                AsNeeded = new CodeableConcept
    //                {
    //                    Coding = new List<Coding>
    //                    {
    //                        new Coding
    //                        {
    //                            System = "http://snomed.info/sct",
    //                            Code = "32914008",
    //                            Display = "Restless Legs"
    //                        }
    //                    }
    //                },
    //                Route = new CodeableConcept
    //                {
    //                    Coding = new List<Coding>
    //                    {
    //                        new Coding
    //                        {
    //                            System = "http://snomed.info/sct",
    //                            Code = "26643006",
    //                            Display = "Oral Route"
    //                        }
    //                    }
    //                },
    //                DoseRange = new Range
    //                {
    //                    Low = new SimpleQuantity
    //                    {
    //                        Value = 1,
    //                        Unit = "TAB",
    //                        System = "http://hl7.org/fhir/v3/orderableDrugForm",
    //                        Code = "TAB"
    //                    },
    //                    High = new SimpleQuantity
    //                    {
    //                        Value = 2,
    //                        Unit = "TAB",
    //                        System = "http://hl7.org/fhir/v3/orderableDrugForm",
    //                        Code = "TAB"
    //                    }
    //                }
    //            }
    //        }
    //    };

    //    // Create the contained Medication resource
    //    R3Model.Medication medication = new R3Model.Medication
    //    {
    //        Id = "med0309",
    //        Code = new CodeableConcept
    //        {
    //            Coding = new List<Coding>
    //            {
    //                new Coding
    //                {
    //                    System = "http://hl7.org/fhir/sid/ndc",
    //                    Code = "50580-506-02",
    //                    Display = "Tylenol PM"
    //                }
    //            }
    //        },
    //        IsBrand = true,
    //        Form = new CodeableConcept
    //        {
    //            Coding = new List<Coding>
    //            {
    //                new Coding
    //                {
    //                    System = "http://snomed.info/sct",
    //                    Code = "385057009",
    //                    Display = "Film-coated tablet (qualifier value)"
    //                }
    //            }
    //        },
    //        Ingredient = new List<Medication.IngredientComponent>
    //        {
    //            new Medication.IngredientComponent
    //            {
    //                Item = new CodeableConcept
    //                {
    //                    Coding = new List<Coding>
    //                    {
    //                        new Coding
    //                        {
    //                            System = "http://www.nlm.nih.gov/research/umls/rxnorm",
    //                            Code = "315266",
    //                            Display = "Acetaminophen 500 MG"
    //                        }
    //                    }
    //                },
    //                Amount = new Ratio
    //                {
    //                    Numerator = new Quantity
    //                    {
    //                        Value = 500,
    //                        System = "http://unitsofmeasure.org",
    //                        Code = "mg"
    //                    },
    //                    Denominator = new Quantity
    //                    {
    //                        Value = 1,
    //                        System = "http://hl7.org/fhir/v3/orderableDrugForm",
    //                        Code = "Tab"
    //                    }
    //                }
    //            },
    //            new Medication.MedicationIngredientComponent
    //            {
    //                Item = new CodeableConcept
    //                {
    //                    Coding = new List<Coding>
    //                    {
    //                        new Coding
    //                        {
    //                            System = "http://www.nlm.nih.gov/research/umls/rxnorm",
    //                            Code = "901813",
    //                            Display = "Diphenhydramine Hydrochloride 25 mg"
    //                        }
    //                    }
    //                },
    //                Amount = new Ratio
    //                {
    //                    Numerator = new Quantity
    //                    {
    //                        Value = 25,
    //                        System = "http://unitsofmeasure.org",
    //                        Code = "mg"
    //                    },
    //                    Denominator = new Quantity
    //                    {
    //                        Value = 1,
    //                        System = "http://hl7.org/fhir/v3/orderableDrugForm",
    //                        Code = "Tab"
    //                    }
    //                }
    //            }
    //        },
    //        Package = new Medication.MedicationPackageComponent
    //        {
    //            Batch = new List<Medication.MedicationBatchComponent>
    //            {
    //                new Medication.MedicationBatchComponent
    //                {
    //                    LotNumber = "9494788",
    //                    ExpirationDate = "2017-05-22"
    //                }
    //            }
    //        }
    //    };

    //    // Add the contained Medication resource
    //    medicationStatement.Contained.Add(medication);

    //    return medicationStatement;
    //}

}
