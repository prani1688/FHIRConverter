﻿extern alias R3;
using AutoMapper;

using Hl7.Fhir.Model;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static R3::Hl7.Fhir.Model.MedicationStatement;
using R3Model = R3.Hl7.Fhir.Model;

public class R3ToR4MappingProfile : Profile
{
    public R3ToR4MappingProfile()
    {
        CreateMap<MedicationStatementStatus, MedicationStatement.MedicationStatusCodes>();
        CreateMap<Code<MedicationStatementStatus>, Code<Hl7.Fhir.Model.MedicationStatement.MedicationStatusCodes>>();
        CreateMap<R3Model.Annotation, Annotation>();
        CreateMap<FhirString, Markdown>();
        CreateMap<R3Model.Dosage, Dosage>();
        CreateMap<R3Model.Timing, Timing>();
        CreateMap<R3Model.Timing.RepeatComponent, Timing.RepeatComponent>();
        CreateMap<R3Model.Ratio, Ratio>();
        CreateMap<Integer, PositiveInt>();
        CreateMap<R3Model.Timing.UnitsOfTime, Timing.UnitsOfTime>();
        CreateMap<Code<R3Model.Timing.UnitsOfTime>, Code<Timing.UnitsOfTime>>();
        CreateMap<Code<R3Model.DaysOfWeek>, Code<DaysOfWeek>>();
        CreateMap<Code<R3Model.Timing.EventTiming>, Code<Timing.EventTiming>>();



        //CreateMap<R3Model.Timing<R3Model.RepeatComponent>, Timing<RepeatComponent>>();
        CreateMap<R3Model.MedicationStatement, MedicationStatement>()
            .ForMember(dest => dest.Identifier, opt => opt.MapFrom(src => src.Identifier))
            .ForMember(dest => dest.BasedOn, opt => opt.MapFrom(src => src.BasedOn))
            .ForMember(dest => dest.PartOf, opt => opt.MapFrom(src => src.PartOf))
        .ForMember(dest => dest.Context, opt => opt.MapFrom(src => src.Context))
            .ForMember(dest => dest.Extension, opt => opt.MapFrom(src => MapExtensions(src)))
        .ForMember(dest => dest.Status, opt => opt.MapFrom(src => MapStatus(src)))
        .ForMember(dest => dest.Category, opt => opt.MapFrom(src => src.Category))
        //.ForMember(dest => dest.Medication, opt => opt.MapFrom(src => MapMedication(src.Medication)))
        .ForMember(dest => dest.Effective, opt => opt.MapFrom(src => MapEffective(src.Effective)))
        .ForMember(dest => dest.DateAsserted, opt => opt.MapFrom(src => src.DateAsserted))
        .ForMember(dest => dest.InformationSource, opt => opt.MapFrom(src => src.InformationSource))
        .ForMember(dest => dest.Subject, opt => opt.MapFrom(src => src.Subject))
        .ForMember(dest => dest.DerivedFrom, opt => opt.MapFrom(src => src.DerivedFrom))
        .ForMember(dest => dest.ReasonCode, opt => opt.MapFrom(src => src.ReasonNotTaken))
        .ForMember(dest => dest.ReasonCode, opt => opt.MapFrom(src => src.ReasonCode))
        .ForMember(dest => dest.ReasonReference, opt => opt.MapFrom(src => src.ReasonReference))
        .ForMember(dest => dest.Note, opt => opt.MapFrom(src => src.Note))
        .ForMember(dest => dest.Dosage, opt => opt.MapFrom(src => src.Dosage))
        .ForMember(dest => dest.StatusElement, opt => opt.MapFrom(src => src.StatusElement));
        #region mapping R3 to R4
        /*
         map "http://hl7.org/fhir/StructureMap/MedicationStatement3to4" = "R3 to R4 Conversions for MedicationStatement"

uses "http://hl7.org/fhir/3.0/StructureDefinition/MedicationStatement" alias MedicationStatementR3 as source
uses "http://hl7.org/fhir/StructureDefinition/MedicationStatement" alias MedicationStatement as target

imports "http://hl7.org/fhir/StructureMap/*3to4"

group MedicationStatement(source src : MedicationStatementR3, target tgt : MedicationStatement) extends DomainResource <<type+>> {
  src.identifier -> tgt.identifier;
  src.basedOn -> tgt.basedOn;
  src.partOf -> tgt.partOf;
  src.context -> tgt.context;
  src.status as v ->  tgt.extension as vt,  vt.url = 'http://hl7.org/fhir/3.0/StructureDefinition/extension-MedicationStatement.status',  vt.value = v;
  src.taken as v ->  tgt.extension as vt,  vt.url = 'http://hl7.org/fhir/3.0/StructureDefinition/extension-MedicationStatement.taken',  vt.value = v;
  src.status where (src.taken in ('n' | 'unk')).not() -> tgt.status;
  src.taken where value = 'n' -> tgt.status = 'not-taken';
  src.taken where value = 'unk' -> tgt.status = 'unknown';
  src.category -> tgt.category;
  src.medication : CodeableConcept as vs -> tgt.medication = create('CodeableConcept') as vt then CodeableConcept(vs, vt);
  src.medication : Reference as vs -> tgt.medication = create('Reference') as vt then Reference(vs, vt);
  src.effective : dateTime as vs -> tgt.effective = create('dateTime') as vt then dateTime(vs, vt);
  src.effective : Period as vs -> tgt.effective = create('Period') as vt then Period(vs, vt);
  src.dateAsserted -> tgt.dateAsserted;
  src.informationSource -> tgt.informationSource;
  src.subject -> tgt.subject;
  src.derivedFrom -> tgt.derivedFrom;
  src.reasonNotTaken -> tgt.reasonCode;
  src.reasonCode -> tgt.reasonCode;
  src.reasonReference -> tgt.reasonReference;
  src.note -> tgt.note;
  src.dosage -> tgt.dosage;
}
         */
        #endregion


    }

    private List<Extension> MapExtensions(R3Model.MedicationStatement source)
    {
        var extensions = new List<Extension>();

        if (source.Status != null)
        {
            extensions.Add(new Extension
            {
                Url = "http://hl7.org/fhir/3.0/StructureDefinition/extension-MedicationStatement.status",
                Value = new FhirString(source.Status.Value.ToString())
            });
        }
        if (source.Taken != null)

        {
            extensions.Add(new Extension
            {
                Url = "http://hl7.org/fhir/3.0/StructureDefinition/extension-MedicationStatement.taken",
                Value = new FhirString(source.Taken.Value.ToString())
            });
        }

        return extensions;
    }

    private MedicationStatement.MedicationStatusCodes? MapStatus(R3Model.MedicationStatement source)
    {
        if (source.Taken != MedicationStatementTaken.N && source.Taken != MedicationStatementTaken.Unk)
        {
            return (MedicationStatement.MedicationStatusCodes)source.Status;
        }
        else if (source.Taken == MedicationStatementTaken.N)
        {
            return MedicationStatement.MedicationStatusCodes.NotTaken;
        }
        else if (source.Taken == MedicationStatementTaken.Unk)
        {
            return MedicationStatement.MedicationStatusCodes.Unknown;
        }
        return null; // Handle other cases if needed.
    }

    private Extension CreateExtensionFromStatus(R3Model.MedicationStatement.MedicationStatementStatus? statusValue)
    {
        var extension = new Extension
        {
            Url = "http://hl7.org/fhir/3.0/StructureDefinition/extension-MedicationStatement.status",
            Value = new FhirString(statusValue.ToString())
        };
        return extension;
    }
    private Extension CreateExtensionFromTaken(R3Model.MedicationStatement.MedicationStatementTaken? takenValue)
    {
        var extension = new Extension
        {
            Url = "http://hl7.org/fhir/3.0/StructureDefinition/extension-MedicationStatement.taken",
            Value = new FhirString(takenValue.ToString())
        };
        return extension;
    }

    private object MapMedication(object sourceMedication)
    {
        if (sourceMedication == null)
        {
            return null;
        }

        if (sourceMedication is CodeableConcept)
        {
            var sourceCodeableConcept = (CodeableConcept)sourceMedication;
            var targetCodeableConcept = new CodeableConcept();
            // You can copy properties from the source to the target as needed.
            targetCodeableConcept.Coding = sourceCodeableConcept.Coding;
            targetCodeableConcept.Text = sourceCodeableConcept.Text;
            return targetCodeableConcept;
        }
        //else if (sourceMedication is Reference)
        //{
        //    var sourceReference = (Reference)sourceMedication;
        //    var targetReference = new Reference(sourceReference.Reference);
        //    // You can copy other properties from the source to the target as needed.
        //    targetReference.Display = sourceReference.Display;
        //    return targetReference;
        //}

        // Handle other cases if needed.

        return null; // Return null for unsupported types.
    }


    private object MapEffective(object sourceEffective)
    {
        if (sourceEffective == null)
        {
            return null;
        }

        if (sourceEffective is FhirDateTime)
        {
            var sourceDateTime = (FhirDateTime)sourceEffective;
            var targetDateTime = new FhirDateTime(sourceDateTime.Value);
            return targetDateTime;
        }
        else if (sourceEffective is Period)
        {
            var sourcePeriod = (Period)sourceEffective;
            var targetPeriod = new Period();
            // You can copy properties from the source to the target as needed.
            targetPeriod.Start = sourcePeriod.Start;
            targetPeriod.End = sourcePeriod.End;
            return targetPeriod;
        }

        // Handle other cases if needed.

        return null; // Return null for unsupported types.
    }

    private CodeableConcept MapToCodeableConcept(R3Model.Medication sourceCodeableConcept)
    {
        if (sourceCodeableConcept == null)
        {
            return null;
        }

        var targetCodeableConcept = new CodeableConcept();

        // Copy properties from the source to the target, or perform any custom mapping logic as needed.
        // For example, you might copy coding information from source to target.
        //targetCodeableConcept.Coding = ((R3 CodeableConcept ) sourceCodeableConcept).Coding;
        //targetCodeableConcept.Text = sourceCodeableConcept.Text;

        return targetCodeableConcept;
    }
}
