﻿extern alias R3;
using AutoMapper;
using Hl7.Fhir.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static R3::Hl7.Fhir.Model.MedicationStatement;
using R3Model = R3.Hl7.Fhir.Model;

namespace FHIR.HL7
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize AutoMapper and configure it with the custom profile
            var config = new MapperConfiguration(cfg => cfg.AddProfile<R3ToR4MappingProfile>());
            var mapper = new Mapper(config);

            // Your JSON data in FHIR R3 format (example)
            string jsonR3Data = @"{
                'status': 'active',
                'taken': 'n'
            }";

            // Deserialize the JSON data to your FHIR R3 source object
            var source = JsonConvert.DeserializeObject<R3Model.MedicationStatement>(jsonR3Data);

            // Map the FHIR R3 object to FHIR R4
            var target = mapper.Map<MedicationStatement>(source);

            // Serialize the FHIR R4 object to JSON (example)
            string jsonR4Data = JsonConvert.SerializeObject(target, Formatting.Indented);
            Console.WriteLine("FHIR R4 Data:");
            Console.WriteLine(jsonR4Data);

            // You can perform further processing or save the converted data as needed.
        }
    }
}
